<!DOCTYPE html>
<html lang='en'>
  <head>
    <title>Asheville Farmers Market <?php echo h($page_title);?> - Admin</title>
    <meta charset='utf-8'>
    <link rel="stylesheet" href="<?php echo url_for('/stylesheets/public.css') ?>;">
  </head>

  <body>
    <header>
      <h1>Working Header - Admin</h1>
    </header>
  </body>
</html>
