<footer>
  <p>$copy; <?= date('Y'); ?> Asheville Farmers Market - Admin</p>
</footer>
<? 
