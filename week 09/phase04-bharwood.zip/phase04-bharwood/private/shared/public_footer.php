<footer>
  <p>&copy; <?= date('Y'); ?> Asheville Farmers Market</p>
</footer>
<? 
