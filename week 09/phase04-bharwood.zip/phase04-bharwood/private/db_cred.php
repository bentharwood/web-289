<?php
//database connection 
define("DB_SERVER", "localhost");
define("DB_USER", "secureUser");
define("DB_PASS", "password");
define("DB_NAME", "farmers_market_db");
