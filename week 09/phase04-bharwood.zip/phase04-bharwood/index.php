<?php 
  require_once('private/initialize.php'); 
  redirect_to(url_for('public/index.php')) 
?>
