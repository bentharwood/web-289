<?php 
require_once('../../private/initialize.php'); 

$page_title = 'Home';
include(SHARED_PATH . '/public_header.php');

?>

<?php
include(SHARED_PATH . '/public_footer.php');

?>
