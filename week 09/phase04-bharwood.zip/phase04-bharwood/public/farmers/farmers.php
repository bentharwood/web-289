<?php require_once('../../private/initialize.php');
$page_title = 'Our Farmers';
include(SHARED_PATH . '/public_header.php');
?>
<h1>farmers stub</h1>
