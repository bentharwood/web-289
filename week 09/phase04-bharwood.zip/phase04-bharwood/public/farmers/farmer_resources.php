<?php require_once('../../private/initialize.php');
$page_title = 'Farmer Resources';
include(SHARED_PATH . '/public_header.php');
?><h1>resources stub</h1>
