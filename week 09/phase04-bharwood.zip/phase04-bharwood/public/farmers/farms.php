<?php require_once('../../private/initialize.php');
$page_title = 'Our Farms';
include(SHARED_PATH . '/public_header.php');
?>
<h1>farm stub</h1>
