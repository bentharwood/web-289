<?php require_once('../../private/initialize.php');
$page_title = 'Latest produce';
include(SHARED_PATH . '/public_header.php');
?>
<h1>latest stub</h1>
