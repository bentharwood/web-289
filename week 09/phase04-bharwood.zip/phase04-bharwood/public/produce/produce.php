<?php require_once('../../private/initialize.php');
$page_title = 'produce';
include(SHARED_PATH . '/public_header.php');
?>
<h1>produce stub</h1>
