<?php require_once('../../private/initialize.php');
$page_title = 'Local produce';
include(SHARED_PATH . '/public_header.php');
?>
<h1>local stub</h1>
