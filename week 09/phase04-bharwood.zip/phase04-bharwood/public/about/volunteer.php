<?php require_once('../../private/initialize.php');
$page_title = 'Volunteer';
include(SHARED_PATH . '/public_header.php');
?>
<h1>Volunteer</h1>