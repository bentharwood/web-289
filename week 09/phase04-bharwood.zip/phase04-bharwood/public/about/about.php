<?php require_once('../../private/initialize.php');
$page_title = 'About us';
include(SHARED_PATH . '/public_header.php');
?>
<h1> about stub</h1>
