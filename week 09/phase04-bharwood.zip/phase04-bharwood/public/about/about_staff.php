<?php require_once('../../private/initialize.php');
$page_title = 'About Our Staff';
include(SHARED_PATH . '/public_header.php');
?>
<h1>about staff stub</h1>
