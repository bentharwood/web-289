<?php 
//database connection
define("DB_SERVER", "localhost");
define("DB_USER", "FreshFieldsWeb");
define("DB_PASS", "password");
define("DB_NAME", "freshfields");
