<?php
require_once('../../private/initialize.php');

$errors = [];
$username = '';
$password = '';

if (is_post_request()) {
  if ($session->is_logged_in()) {
    // If the user is already logged in, log them out first
    $session->logout();
  }

  $username = $_POST['username'] ?? '';
  $password = $_POST['password'] ?? '';
  // Validations
  if (is_blank($username)) {
    $errors[] = "Username cannot be blank.";
  }
  if (is_blank($password)) {
    $errors[] = "Password cannot be blank.";
  }

  // if there were no errors, try to login
  if (empty($errors)) {
    $user = users::find_by_username($username);
    // test if user found and password is correct
    if ($user != false && $user->verify_password($password)) {
      // Mark user as logged in
      $session->login($user);
      if ($session->check_is_admin() == 1) {
        redirect_to(url_for('admin/admin_index.php'));
      } else
        redirect_to(url_for('members/index.php'));
    } else {
      // username not found or password does not match
      $errors[] = "Log in was unsuccessful.";
    }
  }
}
?>


<h2>Log In</h2>
<button id="signup-button">Dont have an account?<br>Click Here To Signup!!!</button>
<?php echo display_errors($errors);
?>

<form action="<?php SHARED_PATH . 'shared/login.php' ?>" method="post">



  <div>
    <label for="username">Username</label>
    <input type="text" name="username" id="username" placeholder="Username" required>
  </div>

  <div>
    <label for="password">Password</label>
    <input type="password" name="password" id="password" value="" placeholder="password" required>

    <input type="submit" name="Log in" value="Log In">
  </div>
</form>