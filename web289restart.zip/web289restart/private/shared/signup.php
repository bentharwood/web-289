<?php
require_once('../../private/initialize.php');
if (is_post_request()) {

  $args = $_POST['user'];
  $user->user_id = uniqid(true);
  $user->is_admin;
  $user = new users($args);
  $result = $user->save();

  if ($result === true) {
    $new_id = $user->user_id;
    $_SESSION['message'] = 'Welcome' . $user->username();
    redirect_to(url_for('/index.php'));
  } else {
  }
} else {
  $user = new users;
}

?>
<h1>Sign Up!</h1>
<?php echo display_errors($user->errors);
?>


<form action="<?php url_for('../private/shared/signup.php'); ?>" method="post">
  <label for="username">Username:</label>
  <input type="text" id="username" name="user[username]" value="<?php echo h($user->username); ?>" required>

  <label for="email">Email:</label>
  <input type="email" id="email" name="user[email]" value="<?php echo h($user->email); ?>">

  <label for="password">Password:</label>
  <input type="password" id="password" name="user[password]" required>

  <label for="confirm_password">Confirm Password:</label>
  <input type="password" id="confirm_password" name="user[confirm_password]" required>

  <input type="submit" value="Sign Up!" />

</form>