<?php require_once('../private/initialize.php') ;
  $errors = [];
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <meta name="description" content="<?php echo (isset($description))  ? $description : 'This project is my capstone for my web and software development degree' ?> Author: Ben Harwood">
  <title><?php echo (isset($page_title)) ? $page_title : "Fresh Fields Market" ?></title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200">
  <link rel="stylesheet" href="<?php echo url_for('css/styles.css') ?>">
  <link rel="icon" type="image/x-icon" href="<?php echo url_for('imgs/fresh-fields-logo.svg') ?>">
  <script src="<?php echo url_for('js/modal.js') ?>" defer></script>
</head>

<body>
  <header>
    <section>
      <div>
        <a href="<?php echo url_for('index.php'); ?>">
          <img src="<?php echo url_for('imgs/fresh-fields-logo.svg') ?>" alt="A bulls head logo." height="75" width="75">
        </a>
        <a href="<?php echo url_for('index.php'); ?>">
          <h1>Fresh Fields Market</h1>
        </a>
      </div>

      <div class="moduleButtons">
      <?php if (!$session->is_logged_in()) : ?>
        <button id="login">
          <span class="material-symbols-outlined">login</span> Login
        </button>
        <?php else : ?>
        <?php endif; ?>

        <button id="viewCart">
          <span class="material-symbols-outlined">shopping_cart</span> View Cart
        </button>
      </div>
    </section>

    <div id="modalOuterBox">
      <div id="modalContent">

      </div>
    </div>
    <div id="sysMessage">

    </div>


    <nav>
      <div class="dropdown">
        <p>Shop<span class="material-symbols-outlined">arrow_drop_down</span></p>
        <ul>
          <li><a href="#">Shop All<span class="material-symbols-outlined">arrow_outward</span></a></li>
          <li><a href="#">Shop Seasonal<span class="material-symbols-outlined">arrow_outward</span></a></li>
          <li><a href="#">Shop Wholesale<span class="material-symbols-outlined">arrow_outward</span></a></li>
        </ul>
      </div>

      <div class="dropdown">
        <p>Meats<span class="material-symbols-outlined">arrow_drop_down</span></p>
        <ul>
          <li><a href="#">100% Grass-Fed Beef<span class="material-symbols-outlined">arrow_outward</span></a></li>
          <li><a href="#">Free range Chicken<span class="material-symbols-outlined">arrow_outward</span></a></li>
          <li><a href="#">Pasture Raised Pork<span class="material-symbols-outlined">arrow_outward</span></a></li>
        </ul>
      </div>

      <div class="dropdown">
        <p>Produce<span class="material-symbols-outlined">arrow_drop_down</span></p>
        <ul>
          <li><a href="#">Seasonal Vegetables<span class="material-symbols-outlined">arrow_outward</span></a></li>
          <li><a href="#">Seasonal Fruit<span class="material-symbols-outlined">arrow_outward</span></a></li>
          <li><a href="#">Berry Picking<span class="material-symbols-outlined">arrow_outward</span></a></li>
        </ul>
      </div>


      <div class="dropdown">
        <p>Our Farms<span class="material-symbols-outlined">arrow_drop_down</span></p>
        <ul>
          <li><a href="#">Farm Profiles<span class="material-symbols-outlined">arrow_outward</span></a></li>
          <li><a href="#">Sustainability<span class="material-symbols-outlined">arrow_outward</span></a></li>
          <li><a href="#">Farmers' Stories<span class="material-symbols-outlined">arrow_outward</span></a></li>
        </ul>
      </div>

      <div class="dropdown">
        <p>About<span class="material-symbols-outlined">arrow_drop_down</span></p>
        <ul>
          <li><a href="#">Market History<span class="material-symbols-outlined">arrow_outward</span></a></li>
          <li><a href="#">Contact Information<span class="material-symbols-outlined">arrow_outward</span></a></li>
          <li><a href="#">FAQs<span class="material-symbols-outlined">arrow_outward</span></a></li>
        </ul>
      </div>

      <div class="dropdown">
        <p>Events<span class="material-symbols-outlined">arrow_drop_down</span></p>
        <ul>
          <li><a href="#">Upcoming Events<span class="material-symbols-outlined">arrow_outward</span></a></li>
          <li><a href="#">Past Events<span class="material-symbols-outlined">arrow_outward</span></a></li>
          <li><a href="#">Vendor Spotlight<span class="material-symbols-outlined">arrow_outward</span></a></li>
        </ul>
      </div>
    </nav>

    <div>
    <?php echo $session->message(); ?>
    </div>

  </header>