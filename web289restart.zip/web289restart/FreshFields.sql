-- Create the FreshFields database
CREATE DATABASE IF NOT EXISTS FreshFields;

-- Switch to the FreshFields database
USE FreshFields;

-- Create the users table
CREATE TABLE IF NOT EXISTS users (
    user_id INT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    hashed_password VARCHAR(255) NOT NULL,
    is_admin boolean  NOT NULL default 0
);

-- Create the vendors table
CREATE TABLE IF NOT EXISTS vendors (
    vendor_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    vendor_address VARCHAR(50) NOT NULL, 
    vendor_name VARCHAR(50) NOT NULL,
    vendor_description VARCHAR(255) NOT NULL,
    vendor_info JSON,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
);

-- Create the goods table
CREATE TABLE IF NOT EXISTS goods (
    good_id INT PRIMARY KEY AUTO_INCREMENT,
    good_name VARCHAR(100) NOT NULL,
    good_description VARCHAR(255) NOT NULL,
);

