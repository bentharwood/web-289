'use strict';

// Call loginModal function when the document is ready
document.addEventListener('DOMContentLoaded', function () {
  Modal('login.php'); // Default login button behavior
  Modal('cart.php', '#viewCart'); // Behavior for the View Cart button
  // Behavior for the Signup button
});

/**
 * login popup action
 */
function Modal(page, buttonId, isSignupButton = false) {
  const BUTTON = buttonId ? document.querySelector(buttonId) : document.querySelector('#login');
  // const SIGNUP = document.getElementById('signup-button');
  const BOXOUT = document.querySelector('#modalOuterBox');
  const BOXIN = document.querySelector('#modalContent');

  // Function to close the modal
  function closeModal() {
    BOXIN.innerHTML = ''; // Clear the modal content
    BOXOUT.style.display = 'none';
  }

  // closes the modal if you click outside it
  BOXOUT.addEventListener('click', function (e) {
    if (e.target === BOXOUT) {
      closeModal();
    }
  });

  // shows modal when login button is clicked or signup button if specified
  if (BUTTON != null) {
    BUTTON.addEventListener('click', function () {
      BOXIN.innerHTML = '';
      // fetch content of specified page using AJAX
      let contentRequest = new XMLHttpRequest();
      contentRequest.open('GET', '/web289restart/private/shared/' + page, true);
      contentRequest.onreadystatechange = function () {
        if (contentRequest.readyState == 4 && contentRequest.status == 200) {
          // insert the response html into the dom
          BOXIN.insertAdjacentHTML('beforeend', contentRequest.responseText);
          // display the popup
          BOXOUT.style.display = 'flex';
          Modal('signup.php', '#signup-button', true);
        }
      };
      contentRequest.send();
    });
  }
}
