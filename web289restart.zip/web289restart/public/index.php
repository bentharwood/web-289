<?php require_once('../private/initialize.php') ?>

  <?php require_once(SHARED_PATH . '/header.php'); 
  ?>
    <main>
      <a href="<?php echo url_for('members/signup.php') ?>">aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa</a>
    
    </main>
  <?php require_once(SHARED_PATH . '/footer.php') ?>
</html>